package com.example.aula2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class OutroActivity extends AppCompatActivity {

    String msg = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outro);

        Intent intent = getIntent();
        String valor = intent.getStringExtra("resultado");
        TextView t = findViewById(R.id.resultTempC);
        t.setText(t.getText() + valor + " Fº");
    }
}